# CV Assignment-3

## Question 1 

Modify Faster R-CNN for predicting Oriented Bounding Boxes